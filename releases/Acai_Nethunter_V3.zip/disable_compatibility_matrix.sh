# Acai @github.com/acai66


## AnyKernel methods (DO NOT CHANGE)
# import patching functions/variables - see for reference
. tools/ak3-core.sh;


## disable android compatibility-matrix for CONFIGS

mount -o rw,remount -t auto /system;
test -e /dev/block/bootdevice/by-name/system || local slot=$(getprop ro.boot.slot_suffix 2>/dev/null);
ui_print $slot
mount -o rw,remount -t auto /dev/block/bootdevice/by-name/system$slot /system_root;
SYSTEM="/system";
SYSTEM_ROOT="/system_root";

disable_check_by_replace(){
    MODDIR=/data/adb/modules/ak3-helper/system;
    replace_line_mod $MODDIR/etc/vintf/compatibility_matrix.1.xml $1 $2 
    replace_line_mod $MODDIR/etc/vintf/compatibility_matrix.2.xml $1 $2 
    replace_line_mod $MODDIR/etc/vintf/compatibility_matrix.3.xml $1 $2
    replace_line_mod $MODDIR/etc/vintf/compatibility_matrix.4.xml $1 $2
    replace_line_mod $MODDIR/etc/vintf/compatibility_matrix.device.xml $1 $2
    replace_line_mod $MODDIR/etc/vintf/compatibility_matrix.legacy.xml $1 $2 
}
[ -d /data/adb/modules/ak3-helper ] && {
    moddir=/data/adb/modules/ak3-helper/system/etc/vintf;
    rm -rf $moddir;
    mkdir -p $moddir;
    cp -r $SYSTEM/etc/vintf/* "$moddir/";

    disable_check_by_replace "<key>CONFIG_NFS_FS</key>" "<key>CONFIG_USELIB</key>";
    disable_check_by_replace "<key>CONFIG_SYSVIPC</key>" "<key>CONFIG_USELIB</key>";
    disable_check_by_replace "<key>CONFIG_NFSD</key>" "<key>CONFIG_USELIB</key>";
}

mount -o ro,remount -t auto /system;
## End

